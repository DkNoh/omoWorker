@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

if not exist "pom.xml" (
  echo [ERROR] pom.xml을 찾을 수 없습니다.
  echo 이 파일을 프로젝트 저장소 루트에서 실행하세요.
  exit /b 1

)

echo [주의] 폐쇄망 반입 전 삭제 대상 91개 파일을 제거합니다.
echo 삭제 대상은 리스트.txt의 [삭제할 파일]과 동일합니다.
choice /C YN /N /M "계속하시겠습니까? [Y/N] "
if errorlevel 2 (
  echo 취소했습니다.
  exit /b 0

)

set /a DELETED=0
set /a NOT_FOUND=0
set /a FAILED=0

call :delete "CLAUDE.md"
call :delete "docs\analysis\01-architecture.md"
call :delete "docs\analysis\02-auth-and-security.md"
call :delete "docs\analysis\03-sms-history-feature.md"
call :delete "docs\analysis\04-scaffold-engine.md"
call :delete "docs\analysis\05-data-model.md"
call :delete "docs\analysis\06-common-infrastructure.md"
call :delete "docs\analysis\07-mybatis-sql-inventory.md"
call :delete "docs\analysis\08-conventions-and-debt.md"
call :delete "docs\analysis\INDEX.md"
call :delete "docs\analysis\design-pattern-review.md"
call :delete "docs\analysis\frontend-improvement-plan.md"
call :delete "docs\analysis\frontend-modification-plan.md"
call :delete "docs\analysis\frontend-modification-spec.md"
call :delete "docs\궁금.md"
call :delete "docs\진행.md"
call :delete "src\main\java\com\scbk\sms\controller\basic\NoticeController.java"
call :delete "src\main\java\com\scbk\sms\controller\sms\SmsHistoryController.java"
call :delete "src\main\java\com\scbk\sms\controller\sms\SmsRegisterController.java"
call :delete "src\main\java\com\scbk\sms\controller\system\MessageController.java"
call :delete "src\main\java\com\scbk\sms\dto\basic\NoticeSearchRequestDTO.java"
call :delete "src\main\java\com\scbk\sms\dto\basic\NoticeUpdateRequestDTO.java"
call :delete "src\main\java\com\scbk\sms\dto\sms\SmsHistorySearchRequestDTO.java"
call :delete "src\main\java\com\scbk\sms\dto\sms\SmsHistoryUpdateRequestDTO.java"
call :delete "src\main\java\com\scbk\sms\mapper\basic\NoticeMapper.java"
call :delete "src\main\java\com\scbk\sms\mapper\sms\SmsHistoryMapper.java"
call :delete "src\main\java\com\scbk\sms\service\basic\NoticeService.java"
call :delete "src\main\java\com\scbk\sms\service\sms\SmsHistoryService.java"
call :delete "src\main\java\com\scbk\sms\vo\basic\NoticeVO.java"
call :delete "src\main\java\com\scbk\sms\vo\sms\SmsHistoryVO.java"
call :delete "src\main\resources\mapper\basic\NoticeMapper.xml"
call :delete "src\main\resources\mapper\sms\SmsHistoryMapper.xml"
call :delete "src\main\resources\static\js\basic\notice-popup.js"
call :delete "src\main\resources\static\js\basic\notice.js"
call :delete "src\main\resources\static\js\sms\history.js"
call :delete "src\main\resources\templates\basic\notice-popup.html"
call :delete "src\main\resources\templates\basic\notice.html"
call :delete "src\main\resources\templates\sms\campaign-register.html"
call :delete "src\main\resources\templates\sms\history.html"
call :delete "src\main\resources\templates\system\message-edit.html"
call :delete "src\test\java\com\scbk\sms\NoticeEditPatternContractTest.java"
call :delete "src\test\java\com\scbk\sms\NoticePopupContractTest.java"
call :delete "src\test\java\com\scbk\sms\controller\basic\NoticeControllerTest.java"
call :delete "src\test\java\com\scbk\sms\controller\sms\SmsHistoryControllerTest.java"
call :delete "src\test\java\com\scbk\sms\controller\sms\SmsRegisterControllerTest.java"
call :delete "src\test\java\com\scbk\sms\service\basic\NoticeServiceTest.java"
call :delete "src\test\java\com\scbk\sms\service\sms\SmsHistoryServiceTest.java"
call :delete "src\test\resources\scaffold-golden\db2_CONTROLLER.txt"
call :delete "src\test\resources\scaffold-golden\db2_CONTROLLER_TEST.txt"
call :delete "src\test\resources\scaffold-golden\db2_DTO.txt"
call :delete "src\test\resources\scaffold-golden\db2_HTML.txt"
call :delete "src\test\resources\scaffold-golden\db2_JS.txt"
call :delete "src\test\resources\scaffold-golden\db2_MAPPER_INTERFACE.txt"
call :delete "src\test\resources\scaffold-golden\db2_MENU_SQL.txt"
call :delete "src\test\resources\scaffold-golden\db2_SERVICE.txt"
call :delete "src\test\resources\scaffold-golden\db2_SERVICE_TEST.txt"
call :delete "src\test\resources\scaffold-golden\db2_UPDATE_REQUEST_DTO.txt"
call :delete "src\test\resources\scaffold-golden\db2_VO.txt"
call :delete "src\test\resources\scaffold-golden\keyword_CONTROLLER.txt"
call :delete "src\test\resources\scaffold-golden\keyword_CONTROLLER_TEST.txt"
call :delete "src\test\resources\scaffold-golden\keyword_DTO.txt"
call :delete "src\test\resources\scaffold-golden\keyword_HTML.txt"
call :delete "src\test\resources\scaffold-golden\keyword_JS.txt"
call :delete "src\test\resources\scaffold-golden\keyword_MAPPER_INTERFACE.txt"
call :delete "src\test\resources\scaffold-golden\keyword_MAPPER_XML.txt"
call :delete "src\test\resources\scaffold-golden\keyword_MENU_SQL.txt"
call :delete "src\test\resources\scaffold-golden\keyword_SERVICE.txt"
call :delete "src\test\resources\scaffold-golden\keyword_SERVICE_TEST.txt"
call :delete "src\test\resources\scaffold-golden\keyword_VO.txt"
call :delete "src\test\resources\scaffold-golden\mssql_CONTROLLER.txt"
call :delete "src\test\resources\scaffold-golden\mssql_CONTROLLER_TEST.txt"
call :delete "src\test\resources\scaffold-golden\mssql_DTO.txt"
call :delete "src\test\resources\scaffold-golden\mssql_HTML.txt"
call :delete "src\test\resources\scaffold-golden\mssql_JS.txt"
call :delete "src\test\resources\scaffold-golden\mssql_MAPPER_INTERFACE.txt"
call :delete "src\test\resources\scaffold-golden\mssql_MENU_SQL.txt"
call :delete "src\test\resources\scaffold-golden\mssql_SERVICE.txt"
call :delete "src\test\resources\scaffold-golden\mssql_SERVICE_TEST.txt"
call :delete "src\test\resources\scaffold-golden\mssql_UPDATE_REQUEST_DTO.txt"
call :delete "src\test\resources\scaffold-golden\mssql_VO.txt"
call :delete "src\test\resources\scaffold-golden\postgres_CONTROLLER.txt"
call :delete "src\test\resources\scaffold-golden\postgres_CONTROLLER_TEST.txt"
call :delete "src\test\resources\scaffold-golden\postgres_DTO.txt"
call :delete "src\test\resources\scaffold-golden\postgres_HTML.txt"
call :delete "src\test\resources\scaffold-golden\postgres_JS.txt"
call :delete "src\test\resources\scaffold-golden\postgres_MAPPER_INTERFACE.txt"
call :delete "src\test\resources\scaffold-golden\postgres_MENU_SQL.txt"
call :delete "src\test\resources\scaffold-golden\postgres_SERVICE.txt"
call :delete "src\test\resources\scaffold-golden\postgres_SERVICE_TEST.txt"
call :delete "src\test\resources\scaffold-golden\postgres_UPDATE_REQUEST_DTO.txt"
call :delete "src\test\resources\scaffold-golden\postgres_VO.txt"

echo.
echo 삭제 완료: !DELETED!개
echo 기존에 없음: !NOT_FOUND!개
echo 삭제 실패: !FAILED!개
if not "!FAILED!"=="0" exit /b 1
exit /b 0

:delete
if exist "%~1" (
  del /f /q "%~1" >nul 2>&1
  if exist "%~1" (
    echo [FAIL] %~1
    set /a FAILED+=1
  ) else (
    echo [DELETE] %~1
    set /a DELETED+=1
  )
) else (
  echo [SKIP] %~1
  set /a NOT_FOUND+=1
)
exit /b 0
