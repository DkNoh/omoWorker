package com.scbk.sms.dto.system;

import lombok.Data;

@Data
public class ScaffoldSearchParamOptionDTO {

  private String name;
  private String label;
  private String inputType;
  private String defaultValue;
  private String optionsText;
}
