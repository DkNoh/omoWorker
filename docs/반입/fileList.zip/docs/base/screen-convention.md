# 화면 규약 (Screen Convention)

v3 업무 화면은 v2 운영 화면과 동일한 구조로 생성한다. 이 문서는 v2의 화면 규약을 v3 기준으로 고정한 것이다.

화면은 이 문서에 문서화된 패턴(목록 화면, 상세폼 화면, 수동 모달)으로 구성한다. 패턴에 없는 화면 고유 정보 구조(미리보기 패널 등)는 허용한다. 단, 공통 자산(그리드·HTTP·모달·상세폼 행 레이아웃)을 화면마다 새로 발명하지 않는다.

## 기술 스택

| 항목 | 기준 |
|---|---|
| 레이아웃 | Thymeleaf Layout Dialect + `defaultLayout.html` |
| UI 프레임워크 | CoreUI (Bootstrap 기반) — `static/vendor/coreui` 로컬 참조 |
| 그리드/페이징 | TUI Grid + TUI Pagination — `static/lib` 로컬 참조 |
| 날짜 입력 | Toast UI DatePicker — `static/lib/tui-date-picker.min.js`, `static/lib/tui-date-picker.css` |
| HTTP 클라이언트 | axios — `static/lib/axios.min.js` |
| 엑셀 | xlsx — `static/lib/xlsx.full.min.js` |
| 입력 마스킹 | IMask — `static/lib/imask.min.js` (`field-format.js`가 `data-mask` 요소에 부착, 전화번호/금액 포맷) |
| 폼 검증 | JustValidate — `static/lib/just-validate.min.js` (`field-format.js`/`modal-manager.js`가 선택 사용) |
| 위지윅 에디터 | Toast UI Editor — `static/lib/toastui-editor/3.2.2/` (defaultLayout이 아닌 `basic/notice-popup.html`에서 화면 단위로 로드) |
| 아이콘 | lucide 로컬 번들 — `static/lib/lucide.js`, `data-lucide` 속성으로 렌더링 |
| 공통 CSS | `static/css/admin-common.css`(디자인 토큰: `--sms-*` 정의·CoreUI `--cui-*` 별칭), `admin-layout.css`(쉘/레이아웃), `admin-ui-bridge.css`(CoreUI 브리지), `admin-form-detail.css`(상세폼 행 패턴) — 토큰 계층은 `DESIGN.md` 참조 |
| 공통 JS | `static/js/common/notify.js`, `http-client.js`, `modal-manager.js`, `common-utils.js`, `form-binder.js`, `field-format.js`, `tui-common.js`, `tui-page-builder.js` (의존 순서대로 로드) |
| 날짜 라이브러리 | day.js — `static/lib/dayjs.min.js` + `ko.js` (한국어 locale 전역 활성화: `dayjs.locale('ko')`) |

폐쇄망 기준이므로 CDN 참조를 금지한다. 모든 라이브러리는 `static/lib`, `static/vendor` 로컬 파일만 사용한다.
아이콘도 CDN 대신 `lucide.js` 로컬 파일만 사용한다. 버튼/메뉴/모달 아이콘은 `data-lucide="search"`처럼 이름으로 지정하고, 공통 `CommonUtils.refreshIcons()`가 렌더링을 갱신한다.

## 공통 레이아웃 구조

- 모든 업무 화면은 `layout:decorate="~{defaultLayout}"`를 사용한다.
- 본문은 `<main layout:fragment="content">` 안에 작성한다.
- 화면 전용 스크립트는 `<th:block layout:fragment="script">` 안에 둔다.
- 좌측 사이드바(접기 가능, 256px/64px), 상단 헤더는 `fragments/sidebar.html`, `fragments/header.html`로 분리한다.
- 공통 라이브러리/CSS/JS 로드는 `defaultLayout.html`에서만 한다. 개별 화면에서 중복 로드하지 않는다.

## 목록 화면 표준 골격

목록 화면 패턴의 표준 골격이다. 화면 패턴 중 하나이며, 등록/수정 화면은 아래 "상세폼 화면 패턴"을 본다.
목록 화면은 아래 3개 영역 순서를 고정한다.

```html
<!DOCTYPE html>
<html xmlns:th="http://www.thymeleaf.org"
      xmlns:layout="http://www.ultraq.net.nz/thymeleaf/layout"
      layout:decorate="~{defaultLayout}">
<head>
    <title>화면명</title>
</head>
<body>
<main layout:fragment="content">

    <!-- 1. 화면 제목 + 메뉴 경로 -->
    <div class="content-header">
        <h2>화면명 <small>(대메뉴 &gt; 화면명)</small></h2>
    </div>

    <!-- 2. 검색조건 카드 -->
    <div class="card mb-4 shadow-sm border-0">
        <div class="card-body">
            <div class="row align-items-center g-3">
                <div class="col-auto"><label for="검색조건ID" class="col-form-label fw-bold">조건명</label></div>
                <div class="col-auto"><input type="text" id="검색조건ID" class="form-control"></div>
                <!-- 검색조건 반복 -->
                <div class="col-auto ms-auto d-flex gap-2">
                    <button type="button" id="btn-search" class="btn btn-primary px-4">조회</button>
                    <button type="button" id="btn-reset" class="btn btn-secondary px-3">초기화</button>
                    <button type="button" id="btn-excel" class="btn btn-success ms-1">엑셀</button>
                </div>
            </div>
        </div>
    </div>

    <!-- 3. 그리드 카드 -->
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
            <span class="fs-6 fw-medium">총 <strong class="text-primary" id="total-count">0</strong>건</span>
            <div class="d-flex align-items-center gap-2">
                <select id="pageSizeSelect" class="form-select form-select-sm" style="width:80px;">
                    <option value="10">10건</option><option value="20">20건</option><option value="50">50건</option>
                </select>
            </div>
        </div>
        <div class="card-body p-0"><div id="grid" style="width:100%;"></div></div>
        <div class="card-footer bg-white border-0 py-3"><div id="pagination" class="d-flex justify-content-center"></div></div>
    </div>

</main>
<th:block layout:fragment="script">
    <script th:src="@{/js/도메인/화면명.js}"></script>
</th:block>
</body>
</html>
```

## 상세폼 화면 패턴 (등록/수정)

등록·수정 화면의 행 레이아웃은 공통 CSS(`static/css/admin-form-detail.css`) 클래스로 구성한다. 행 레이아웃을 화면마다 인라인 스타일로 다시 만들지 않는다.

| 클래스 | 용도 |
|---|---|
| `form-detail-row` | 폼 행 — 68px 최소 높이 + 하단 보더, 마지막 행은 보더 제거 |
| `form-detail-label` | 라벨 셀 — 배경·패딩·굵기 |
| `form-detail-control` | 입력 컨트롤 셀 |
| `form-detail-required` | 필수 마커 — ` *` 자동 표시 |
| `form-detail-counter` | 글자수/바이트 카운터 — 화면 JS가 `.is-over` 토글 |

행 1개의 골격:

```html
<div class="row g-0 form-detail-row">
    <div class="col-12 col-sm-3 form-detail-label">
        <label class="form-detail-required" for="fieldId">항목명</label>
    </div>
    <div class="col-12 col-sm-9 form-detail-control">
        <input type="text" class="form-control" id="fieldId" name="fieldId">
    </div>
</div>
```

- 라벨/컨트롤 컬럼 비율(`col-sm-3/9`, `col-sm-2/4/2/4` 등)은 화면 정보 구조에 맞게 고른다.
- `modal-base` 안에서 상세행을 가장자리까지 표시할 때는 폼에 `form-detail-modal-form`을 추가한다.
- 화면 고유 요소(미리보기 패널, 경고 문구, 개별 폭 지정 등)만 `layout:fragment="css"`에 인라인으로 둔다.
- 폼 바인딩·낙관적 잠금·보안 규약은 아래 "수정폼 화면 규약"을 그대로 따른다.
- 정적 샘플: `static/samples/message-edit.html`(단일 컬럼 행 배치), `static/samples/campaign-register.html`(분할 컬럼 + 미리보기 합성). 표준 업무 화면은 먼저 Scaffold로 생성하고, 생성기에 없는 UI 패턴만 샘플에서 선택적으로 참고한다. 샘플 전체를 실제 화면의 원본으로 사용하지 않으며 prod에서는 경로가 차단된다(404).

## ID / 파일 명명 규칙

| 대상 | 규칙 |
|---|---|
| 조회 버튼 | `btn-search` |
| 초기화 버튼 | `btn-reset` |
| 엑셀 버튼 | `btn-excel` |
| 그리드 컨테이너 | `grid` |
| 페이지네이션 | `pagination` |
| 총 건수 | `total-count` |
| 페이지 크기 | `pageSizeSelect` |
| 화면 JS | `static/js/<도메인>/<화면명>.js` (화면 HTML 파일명과 동일) |
| 검색조건 input id | SearchRequestDTO 필드명과 동일한 camelCase |

## 그리드 초기화 규칙

목록 화면 그리드는 `TuiPageBuilder`로만 초기화한다. 화면별로 TUI Grid를 직접 생성하지 않는다.

```javascript
const pageBuilder = new TuiPageBuilder({
    el:           'grid',
    apiUrl:       '/도메인/data',
    searchInputs: ['검색조건ID1', '검색조건ID2'],
    rowHeaders:   ['rowNum'],
    columns: [
        { header: '컬럼명', name: 'voFieldName', width: 110, align: 'center' }
    ]
});
```

- `columns.name`은 VO 필드명과 1:1로 일치해야 한다.
- `searchInputs`는 SearchRequestDTO 필드명과 1:1로 일치해야 한다.

## 공통 JS 유틸 규칙

화면 JS에서 아래 기능은 직접 구현하지 않고 공통 유틸을 사용한다.

| 기능 | 사용법 |
|---|---|
| 알림 | `CommonUtils.toast('저장되었습니다.', 'success')` |
| 확인 모달 | `CommonUtils.confirm('삭제하시겠습니까?', callback)` |
| 금액/전화번호 포맷 | `CommonUtils.fmt.money(...)`, `CommonUtils.fmt.phone(...)` |
| 공통코드 콤보 | `<select data-code-type="...">` + `CommonUtils.initCombos()` |
| 자동완성 | `CommonUtils.initAutocomplete({...})` |
| 공통코드 API | `/api/common-code/{type}` — 지원 타입: `dept`(SMS.DEP), `role`(TB_ROLE). 추가 절차는 `common-code-api-implementation.md` |

`alert()`, `confirm()` 브라우저 기본 다이얼로그는 사용하지 않는다.

## TuiPageBuilder / TuiCommon 계약

공통 그리드 자산의 암묵 규약을 명문화한 것이다. 화면 JS는 이 계약을 전제로 작성한다.

| 항목 | 계약 |
|---|---|
| 그리드 공통 옵션 | `TuiCommon.gridDefaults`가 단일 통제점 (rowHeight 38, bodyHeight 380, scrollX true, scrollY false, minBodyHeight 200). 화면별 예외는 `config.gridOptions`로 넘긴다 |
| 총 건수 표시 | `id="total-count"` 요소 기준. PageBuilder가 자동 갱신한다 |
| 날짜 전송 형식 | Toast UI DatePicker 검색 input(`data-search-type="date"`) 값은 `-`가 제거된 `YYYYMMDD` 문자열로 전송된다 (datetime-local은 `YYYYMMDDHHmm`). DATE/TIMESTAMP 컬럼과 비교하는 SQL은 `TO_DATE(#{변수}, 'YYYYMMDD')`로 감싼다 |
| 기간 검증 | input id가 정확히 `startDate`/`endDate`일 때만 시작일>종료일 검증이 동작한다 |
| 날짜 컬럼 표시 | LocalDate/LocalDateTime 컬럼은 `formatter: TuiCommon.fmt.date`를 붙인다 (scaffold가 자동 부착) |
| 상태/유형 badge | 컬럼 단위로 `formatter: TuiCommon.badgeByValue({ labels, tones })` 선언. `labels`=코드→표시라벨 매핑, `tones`=코드→고정 색(생략 시 라벨 해시 기반 자동 색). 도메인 코드값(SMS/LMS, SUCCESS/FAIL 등)은 공통 JS가 모르게 화면에서 선언한다 |
| 데이터 통신 | **모든 HTTP 호출은 axios로 통일한다** (2026-06-12, fetch 사용처 제거). 전역 인터셉터가 스피너/언래핑/오류 모달을 일괄 담당하므로 화면 JS에서 fetch를 쓰지 않는다 |

## 수정폼 화면 규약 (목록 선택 -> 수정 -> 저장)

목록형(그리드)과 함께 BASE의 두 번째 표준 화면 유형이다.

```text
화면 진입 -> 검색조건 입력 -> 목록 조회
 -> 수정할 행 선택
 -> FormBinder.bind('#editForm', row)   // name 기준 자동 바인딩
 -> 사용자 수정 -> 저장
 -> POST /domain/update (FormBinder.toObject 결과를 UpdateRequestDTO로 수신)
 -> Service 검증/트랜잭션 -> MyBatis update -> 성공/실패
```

### name 일치 계약

수정 가능한 form 필드의 `name` = 응답 JSON 필드명 = `UpdateRequestDTO` 프로퍼티명을 일치시킨다.
수정 화면에 표시만 하는 읽기전용 필드는 `name`을 두지 않거나 `disabled` 처리해 update payload에 들어가지 않게 한다.

```html
<form id="editForm">
    <input type="hidden" name="msgId">
    <input type="hidden" name="beforeUpdateDttm">  <!-- 낙관적 잠금용 -->
    <input type="text" name="msgNm">
    <input type="checkbox" name="useYn">
    <div class="readonly-field" data-field="regDttm">2026-06-18 10:00</div>
    <textarea name="msgCont"></textarea>
</form>
```

### FormBinder (`static/js/common/form-binder.js`)

| API | 동작 |
|---|---|
| `FormBinder.bind(selector, data)` | `data[name]`이 있는 필드만 채움. checkbox는 'Y'/true -> checked, radio는 value 일치 항목 checked. 없는 필드는 건드리지 않음 |
| `FormBinder.toObject(selector)` | name 필드를 객체로 수집. disabled 제외, checkbox -> 'Y'/'N', **빈 문자열 -> null 전송 (확정 정책)** |

```javascript
// 목록에서 수정 행 선택
FormBinder.bind('#editForm', grid.getRow(rowKey));

// 저장
await axios.post('/system/message/update', FormBinder.toObject('#editForm'));
CommonUtils.toast('저장되었습니다.', 'success');
```

### 보안 기준 (자동 바인딩 != 자동 업데이트)

- 조회 응답은 VO(전체 컬럼) 가능. 그러나 **수정 요청은 반드시 `*UpdateRequestDTO`(화이트리스트)로만 받는다.**
- `UpdateRequestDTO`에는 수정 가능한 필드만 선언한다. `REG_ID`/`REG_DTTM`, 시스템 필드, 권한 필드는 선언하지 않는다 — 선언하지 않으면 Jackson이 버리므로 DTO 자체가 화이트리스트다.
- 수정 화면은 표시 필드와 수정 필드를 분리한다. 사용자는 여러 값을 볼 수 있지만, `editable=true` 필드만 input `name`을 갖고 update payload에 포함된다.
- 프론트는 편의 장치일 뿐이다. 화면에서 실수로 많은 값을 보내더라도 서버는 `*UpdateRequestDTO`에 선언된 필드만 수신하고, Mapper XML도 DTO의 수정 허용 필드만 `UPDATE SET`에 사용한다.
- VO를 `@RequestBody`로 받지 않는다 (`ConventionTest`가 자동 검출).
- 소유자 키(EMP_ID/DEP_ID)를 hidden으로 받더라도 서버에서 principal과 재검증한다.

### 낙관적 잠금

- 조회 시 `UPDATE_DTTM`을 `beforeUpdateDttm` hidden에 보관하고 저장 시 함께 전송한다.
- update SQL은 `WHERE PK = #{pk} AND UPDATE_DTTM = #{beforeUpdateDttm}`.
- Service는 update 결과 0건이면 `CustomException(ErrorCode.UPDATE_CONFLICT)`(409, C004)로 실패 처리한다.

## 날짜 처리 규약 (day.js)

화면 JS의 날짜 처리는 day.js를 사용한다. 수기 문자열 조작(substring/replace 체인)으로 날짜를 다루지 않는다.

| 용도 | 형식 | 처리 주체 |
|---|---|---|
| 그리드 표시 | 날짜만 `YYYY-MM-DD`, 일시 `YYYY-MM-DD HH:mm` | `TuiCommon.fmt.date` (컬럼 formatter) |
| 서버 전송 | DatePicker 검색 input(`data-search-type="date"`) -> `YYYYMMDD`, datetime-local -> `YYYYMMDDHHmm` | `TuiPageBuilder`가 자동 변환 |
| 검색조건 기본값 | 오늘 날짜 자동 세팅 | `CommonUtils.setDefaultDateTime` (PageBuilder가 호출) |
| 화면별 날짜 계산 | `dayjs().subtract(1, 'month').format('YYYY-MM-DD')` 형태 | 화면 JS에서 dayjs 직접 사용 |

## axios 응답 처리 규약 (중요)

`common-utils.js`의 전역 인터셉터가 모든 axios 응답을 가공한다. 화면 JS는 이 규약을 전제로 작성한다.

- 성공(code 200): `ApiResponse` 껍데기를 벗긴다. **`response.data`가 곧 알맹이(data)다.** `response.data.data`로 접근하면 안 된다.
- 업무 오류/HTTP 오류: 인터셉터가 서버 메시지를 모달로 표시하고 reject한다. 화면 JS의 catch에서 알림을 중복으로 띄우지 않는다.
- 세션 만료 등으로 로그인 페이지 HTML이 응답으로 오면, 전역 응답 인터셉터(`common-utils.js`)가 이를 감지해 `/login`으로 전환한다. 화면 JS가 `typeof response.data === 'string'`으로 직접 분기하지 않는다.

## 금지

- CDN 참조 금지. 로컬 `static/lib`, `static/vendor`만 사용한다.
- 공통 자산 재발명 금지: 자체 그리드 구현, 자체 HTTP(fetch), 자체 모달(`new coreui.Modal`), 상세폼 행 레이아웃 인라인 재작성. 화면 고유 정보 구조는 문서화된 패턴 합성으로 구현한다.
- `defaultLayout.html`을 거치지 않는 업무 화면 금지 (login.html은 예외).
- 화면에서 권한을 임의 계산하지 않는다. 메뉴/버튼 권한은 서버가 내려준 값만 사용한다.
- 개인정보는 마스킹된 값만 화면에 표시한다.

## 수동 모달 표준 (ModalManager + modal-base.html)

scaffold CRUD screenMode가 생성하는 수정 모달과 개발자가 수동으로 추가하는 비즈니스 모달은 공통 표준을 따른다. LIST/EXCEL에는 자동 상세 모달이나 더블클릭 동작을 추가하지 않는다.

**Fragment** (`fragments/modal-base.html`):
```html
<th:block th:replace="~{fragments/modal-base :: layout(
    modalId=' biz-modal',
    title='제목',
    size='modal-lg',
    bodyContent=~{::#modal-body},
    footerContent=null
)}">
    <div id="modal-body">
        <form id="detail-form" class="form-detail-modal-form" autocomplete="off" novalidate>
            <div class="row g-0 form-detail-row">
                <div class="col-12 col-sm-2 form-detail-label">
                    <label for="fieldId">항목명</label>
                </div>
                <div class="col-12 col-sm-10 form-detail-control">
                    <input type="text" class="form-control" id="fieldId" name="fieldId">
                </div>
            </div>
        </form>
    </div>
</th:block>
```

**DOM id 규약** (modal-manager.js와 계약):
- 모달 컨테이너: `id="${modalId}"`
- 저장 버튼: `id="${modalId}-btn-save"`
- 삭제 버튼: `id="${modalId}-btn-delete"`
- 제목: `id="${modalId}-title"`

**JS 초기화** (`static/js/common/modal-manager.js`):
```javascript
ModalManager.init('biz-modal', {
    onMount:    () => {},
    beforeOpen: () => true,
    onOpen:     () => {},
    onSubmit:   () => { /* 저장 로직 */ },
    onDelete:   () => { /* 삭제 로직 */ },
    onClose:    () => {}
});
ModalManager.open('biz-modal');
ModalManager.close('biz-modal');
```

CoreUI Modal 인스턴스는 `getOrCreateInstance`로 중앙 관리된다. `new coreui.Modal(...)` 직접 생성을 금지한다. `JustValidate`는 선택적으로 `validateRules` 옵션으로 사용할 수 있으며, 기본 검증은 `FieldFormat.validateForm`을 따른다.

## 공통 자산 이식 상태

v2 공통 UI 자산 이식은 완료되었다. 상세 내역은 `docs/base/ui-assets-implementation.md`를 따른다.

- `SESSION_INFO` 전역변수는 v3 인증 모델 기준 `empId`, `depId`, `empNm`, `depNm`을 노출한다.
- 사이드바/헤더의 `user`, `menus` 모델은 `GlobalModelAdvice`가 공통 주입한다. 개별 Controller에서 중복 주입하지 않는다.
- `index.html`은 `defaultLayout` 기반으로 정렬되었다. `login.html`은 레이아웃 미적용 예외 화면이다.
