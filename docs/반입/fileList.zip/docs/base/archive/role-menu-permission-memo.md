# 권한테이블 및 메뉴구성 설계

이 문서는 화면별 조회/등록/수정/삭제 권한을 역할(Role) 기준으로 운영하기 위한 설계안이다. 코드는 수정하지 않았고, 기존 BASE 문서(`docs/base/menu-authority-table-design.md`, `docs/base/dba-request-menu-auth-ddl.md`, `docs/base/emp-dep-identity-policy.md`, `docs/base/menu-source-policy.md`)와 기존 스키마/시드(`db/oracle/01_menu_auth_schema.sql`, `db/oracle/02_menu_auth_seed.sql`)를 그대로 근거로 사용한다.

새 테이블을 만들자는 문서가 아니다. **이미 만들어진 4개 테이블(`TB_ROLE`, `TB_EMP_ROLE`, `TB_MENU`, `TB_MENU_AUTH`)의 구조는 그대로 채택**하고, 현재 비어 있는 "역할별 권한 차등 부여" 부분을 실제 26개 화면 기준으로 어떻게 채워야 하는지를 정리한다.

---

## 1. 왜 EMP/DEP에 권한을 직접 두지 않는가

실제 운영 테이블 구조(`docs/base/emp-dep-identity-policy.md` 기준):

```sql
SMS.DEP (DEP_ID PK, DEP_NM, ACT_YN, ...)

SMS.EMP (
    EMP_ID, DEP_ID,
    ... PERM_CPN, PERM_SYS, PERM_STA, PERM_PSN, PERM_AUT, PERM_NOM, PERM_MMS ...
    CONSTRAINT EMP_PK PRIMARY KEY (EMP_ID, DEP_ID)
)
```

`EMP`는 `EMP_ID + DEP_ID` 복합키이고, `EMP.PERM_*`는 레거시 AS-IS 컬럼이라 v3 권한 판단에 쓸 수 없다(정책으로 금지됨). 그렇다고 권한을 직원 1명 1명에게 직접 주는 구조(`EMP_ID × MENU_ID × 권한플래그`)를 새로 만들면 다음 문제가 생긴다.

- 직원이 1,000명, 화면이 26개면 권한 행이 최대 26,000건이 된다. 신규 화면이 하나 추가될 때마다 직원 수만큼 INSERT가 필요하다.
- "이 사람은 승인 권한을 빼야 한다" 같은 변경이 전 직원 단위로 흩어진다.
- 인사이동/조직변경 시 권한이 따라가지 않는다.

그래서 **직원-화면 사이에 역할(Role)을 한 단계 끼워 넣는다.** 이게 `TB_ROLE` / `TB_EMP_ROLE` / `TB_MENU_AUTH`가 이미 그렇게 설계되어 있는 이유다.

```text
EMP(EMP_ID, DEP_ID) ─── TB_EMP_ROLE ─── TB_ROLE ─── TB_MENU_AUTH ─── TB_MENU
        (직원이 누구인지)      (직원→역할, N:M)   (역할 기준)   (역할→화면별 권한)   (화면이 무엇인지)
```

이렇게 하면 권한 행 개수는 `역할 수(4) × 화면 수(26) = 104건`으로 끝난다. 직원이 늘어나도 `TB_EMP_ROLE`에 한 줄만 추가하면 되고, 권한 자체을 바꿀 때는 역할 단위로 한 번만 바꾸면 그 역할을 가진 모든 직원에게 즉시 반영된다. 이게 이 구조가 "효율적"이라고 부를 수 있는 이유다.

직원 식별은 어디서나 `EMP_ID` 단독이 아니라 `(EMP_ID, DEP_ID)` 복합키로 다뤄야 하므로, `TB_EMP_ROLE`의 PK도 `(EMP_ID, DEP_ID, ROLE_CD)`로 맞춰져 있다 (기존 스키마 그대로, 변경 없음).

---

## 2. 권한 4종(조회/등록/수정/삭제)의 위치

`TB_MENU_AUTH`는 이미 8개 권한 플래그를 갖고 있고, 그중 4개가 요청한 조회/등록/수정/삭제에 해당한다.

| 요청한 권한 | 테이블 컬럼 | 의미 |
|---|---|---|
| 조회 | `CAN_READ` | 화면 접근, 목록/상세 조회 |
| 등록(생성) | `CAN_CREATE` | 신규 등록 |
| 수정 | `CAN_UPDATE` | 수정 |
| 삭제 | `CAN_DELETE` | 삭제 |
| (참고) | `CAN_APPROVE` | 승인/반려 |
| (참고) | `CAN_CANCEL` | 발송취소 등 |
| (참고) | `CAN_DOWNLOAD` | 엑셀/다운로드 |
| (참고) | `CAN_MASK_VIEW` | 개인정보 비마스킹 조회 |

즉 새 컬럼이나 새 테이블이 필요 없다. **부족한 건 테이블 구조가 아니라 "역할별로 이 플래그를 다르게 채우는 시드 데이터"다.** 지금 `db/oracle/02_menu_auth_seed.sql`은 `upsert_menu_auth` 프로시저가 호출될 때마다 8개 플래그를 전부 `'Y'`로 고정하고, 실제로 호출되는 대상도 `ROLE_ADMIN` 하나뿐이다.

```sql
-- 02_menu_auth_seed.sql 현재 상태 (마지막 부분)
FOR R IN (SELECT MENU_ID FROM SMS.TB_MENU WHERE USE_YN = 'Y') LOOP
    upsert_menu_auth(R.MENU_ID, 'ROLE_ADMIN');   -- ROLE_ADMIN만 권한이 생김
END LOOP;
```

`ROLE_MANAGER`, `ROLE_USER`, `ROLE_VIEWER`는 `TB_ROLE`에 정의는 되어 있지만 `TB_MENU_AUTH`에 행이 없다. 권한 판단 로직(`MenuAuthService`, `db 규칙`)은 행이 없으면 권한 없음으로 처리하므로, 이 세 역할로 로그인하면 메뉴가 전부 비어 보이거나 모든 API가 403이 된다. **이게 dev/prod에서 막힐 수 있는 실제 원인이다.**

---

## 3. 역할별 화면 권한 매트릭스 (초안)

`db/oracle/02_menu_auth_seed.sql`에 이미 정의된 6개 그룹·26개 화면 기준으로 역할별 권한을 채운 초안이다. **업무 승인선/보안 등급은 코드나 DB에 없는 정보라 임의로 확정할 수 없으므로, 아래는 화면명·역할 설명(`TB_ROLE.ROLE_DESC`)에서 합리적으로 추론한 제안값이다. 실제 반영 전 업무 담당자 확인이 필요하다 (미확정).**

범례: `R`=CAN_READ, `C`=CAN_CREATE, `U`=CAN_UPDATE, `D`=CAN_DELETE, `A`=CAN_APPROVE, `X`=권한 없음(행 미생성 또는 USE_YN='N')

### G_BASIC (기본메뉴)

| MENU_ID | 화면 | ADMIN | MANAGER | USER | VIEWER |
|---|---|---|---|---|---|
| BASIC_INTRO | SMS관리시스템 안내 | R | R | R | R |
| BASIC_NOTICE | 공지사항 | R,C,U,D | R | R | R |
| BASIC_MESSAGE | 메시지조회 | R | R | R | R |
| BASIC_USER_SEARCH | 사용자조회 | R | R | R | R |
| BASIC_MFA | MFA사용자관리 | R,C,U,D | R,U | R,U | R |

공지사항 등록/수정/삭제는 관리자만, 본인 MFA 설정 변경(U)은 조회 권한이 있는 일반 직원도 필요하다고 보고 USER/MANAGER에 U를 넣었다. VIEWER는 조회 전용 취지에 맞춰 R만 부여한다.

### G_SMS_SEARCH (SMS발송조회)

| MENU_ID | 화면 | ADMIN | MANAGER | USER | VIEWER |
|---|---|---|---|---|---|
| SMS_HISTORY | 발송이력조회 | R | R | R | R |
| SMS_CUSTOMER_SEARCH | 고객별 조회 | R | R | R | R |
| SMS_SSN_SEARCH | 주민번호 조회 | R + MASK_VIEW | R + MASK_VIEW | X | X |

`SMS_SSN_SEARCH`는 주민번호(개인정보) 조회 화면이라 `audit-masking-policy.md` 적용 대상이다. `CAN_MASK_VIEW`(비마스킹 원문 조회)는 ADMIN/MANAGER로 제한하고, USER/VIEWER는 이 화면 자체를 `X`(미부여)로 막는 것을 제안한다. 이 화면의 접근 범위는 보안 정책상 가장 보수적으로 잡아야 하는 항목이라 **반드시 별도 확인이 필요하다.**

### G_CAMPAIGN (캠페인SMS)

| MENU_ID | 화면 | ADMIN | MANAGER | USER | VIEWER |
|---|---|---|---|---|---|
| CAMPAIGN_TARGET | 발송대상관리 | R,C,U,D | R,C,U,D | R | R |
| CAMPAIGN_TARGET_APPROVAL | 발송대상승인 | R,A | R,A | X | X |
| CAMPAIGN_SMS_REGISTER | SMS등록 | R,C,U,D | R,C,U,D | R,C | R |
| CAMPAIGN_LMS_REGISTER | LMS등록 | R,C,U,D | R,C,U,D | R,C | R |
| CAMPAIGN_ALIMTALK_REGISTER | 알림톡등록 | R,C,U,D | R,C,U,D | R,C | R |
| CAMPAIGN_SMS_APPROVE | SMS승인 | R,A | R,A | X | X |
| CAMPAIGN_LMS_APPROVE | LMS승인 | R,A | R,A | X | X |
| CAMPAIGN_ALIMTALK_APPROVE | 알림톡승인 | R,A | R,A | X | X |
| CAMPAIGN_SMS_HISTORY | 발송이력조회 | R | R | R | R |
| CAMPAIGN_LMS_HISTORY | LMS발송이력조회 | R | R | R | R |
| CAMPAIGN_ALIMTALK_HISTORY | 알림톡 발송이력조회 | R | R | R | R |

`ROLE_MANAGER`의 정의(`업무 관리자 — 조회/등록/수정/승인`)와 `ROLE_USER`의 정의(`일반 사용자 — 조회 및 제한된 등록`)를 그대로 화면에 매핑했다. 승인(`*_APPROVE`, `*_APPROVAL`) 화면은 USER/VIEWER에게 아예 비노출(`X`)한다.

### G_SYSTEM (시스템관리) / G_ACCOUNT (계정관리)

| MENU_ID | 화면 | ADMIN | MANAGER | USER | VIEWER |
|---|---|---|---|---|---|
| SYSTEM_DEP | 부서관리 | R,C,U,D | X | X | X |
| SYSTEM_MESSAGE | 메시지 관리 | R,C,U,D | X | X | X |
| SYSTEM_KAKAO_TEMPLATE | 카카오템플릿관리 | R,C,U,D | X | X | X |
| SYSTEM_AD_MESSAGE | 광고성 메시지관리 | R,C,U,D | X | X | X |
| SYSTEM_HOURLY_STATS | 시간대별조회 | R | R | X | X |
| ACCOUNT_USER | 사용자관리 | R,C,U,D | X | X | X |

시스템/계정 관리 영역은 `ROLE_ADMIN` 전용으로 막는다. `SYSTEM_HOURLY_STATS`(통계성 조회)만 MANAGER에게 조회를 열어주는 것을 제안한다.

### G_STATISTICS (통계 관리)

| MENU_ID | 화면 | ADMIN | MANAGER | USER | VIEWER |
|---|---|---|---|---|---|
| STAT_MARKETING_OPTOUT | 마케팅 철회 통계 | R + DOWNLOAD | R + DOWNLOAD | R | R |

다운로드 권한(`CAN_DOWNLOAD`)은 ADMIN/MANAGER로 제한하고 USER/VIEWER는 화면 조회만 가능하게 한다.

---

## 4. 실제 반영 순서 (DB 적용 시)

DBA 반영 문서(`docs/base/dba-request-menu-auth-ddl.md`)에 정의된 순서를 그대로 따르되, 마지막 단계만 "ADMIN 일괄 부여"에서 "역할별 차등 부여"로 바꾼다.

1. `TB_ROLE` — 4개 역할 그대로 사용 (변경 없음, 이미 `02_menu_auth_seed.sql`에 있음)
2. `TB_MENU` — 6그룹/26화면 트리 그대로 사용 (변경 없음)
3. `TB_MENU_AUTH` — **위 3장의 매트릭스대로 역할 × 화면마다 행을 채운다.** 현재 시드처럼 `ROLE_ADMIN`만 채우는 루프 1개가 아니라, 역할마다 별도 루프 또는 매트릭스 테이블을 두고 채워야 한다.
4. `TB_EMP_ROLE` — 직원에게 역할을 배정한다. 한 직원이 여러 역할을 가질 수 있으므로(N:M), 예를 들어 조회만 하는 직원은 `ROLE_VIEWER` 한 줄, 캠페인 승인까지 하는 팀장은 `ROLE_MANAGER` 한 줄을 추가하는 방식이다.

이 순서를 지켜야 하는 이유는 FK 제약 때문이다. `TB_MENU_AUTH`는 `TB_MENU`와 `TB_ROLE`을 모두 참조하고, `TB_EMP_ROLE`은 `EMP(EMP_ID, DEP_ID)`와 `TB_ROLE`을 참조한다. 역할/메뉴가 먼저 존재해야 그 다음 단계가 들어갈 수 있다.

---

## 5. 기존 시드 스크립트의 알려진 문제 (참고)

새 화면을 스케폴드로 만들 때 자동 생성되는 메뉴 SQL(`db/oracle/sms_history_menu_seed.sql` 형태)에는 이미 확인된 결함이 있다. 이 문서의 권한 매트릭스를 실제 SQL로 옮길 때 같이 주의해야 한다.

- `PARENT_MENU_ID` 자리에 `'/* TODO: 상위 메뉴 ID */'` 문자열이 그대로 들어가 있어, 수동으로 실제 그룹 메뉴 ID(`G_SMS_SEARCH` 등)로 바꾸지 않으면 FK 위반으로 INSERT가 실패한다.
- 생성된 `TB_MENU_AUTH` INSERT는 8개 권한 플래그가 전부 `'Y'`이고 역할도 1개(`roleCode`, 기본값 `ROLE_ADMIN`)만 생성한다. 위 매트릭스처럼 역할마다 다른 INSERT 문을 직접 추가해야 한다.
- 신규 화면 1개를 추가할 때마다 3장의 매트릭스에 행을 1개씩 늘리고, 그 화면이 어느 그룹(G_BASIC/G_SMS_SEARCH/G_CAMPAIGN/G_SYSTEM/G_ACCOUNT/G_STATISTICS 중 어디 성격에 가까운지)에 속하는지부터 판단해서 역할 패턴을 따라가면 매번 새로 고민하지 않아도 된다.

이 항목들은 코드(`MenuSqlTemplate.java`, `ScaffoldMenuOptionDTO.java`) 쪽 결함이라 이번 문서에서 코드를 고치지는 않았다. 별도로 다룰 사안이다.

---

## 6. local / dev / prod 차이와의 연결

`docs/base/menu-source-policy.md` 기준으로 `sms.role.source=db`, `sms.menu.source=db`인 환경(dev/prod)에서는 위 4개 테이블 데이터가 그대로 메뉴 노출과 API 권한 판단에 쓰인다. local에서는 `static` 설정으로 항상 `ROLE_ADMIN`을 임시 부여해 전체 메뉴가 보이므로, 위 매트릭스로 인한 차이가 local에서는 보이지 않는다. dev로 전환해 `db` 소스로 검증할 때만 역할별 차이가 실제로 나타난다.

검증 순서 제안:

1. dev에서 `TB_EMP_ROLE`에 테스트 계정을 `ROLE_VIEWER`로 배정한다.
2. 로그인 후 좌측 메뉴에 조회 전용 화면만 보이는지 확인한다.
3. 같은 계정으로 등록/수정 API를 직접 호출해 403이 나는지 확인한다.
4. 계정을 `ROLE_MANAGER`로 바꿔 승인 화면 접근과 승인 액션이 되는지 확인한다.

---

## 7. `TB_EMP_ROLE` 테이블 구조와 사용 방식

`TB_EMP_ROLE`은 사용자별 화면 권한을 저장하는 테이블이 아니라, `EMP + DEP` 사용자에게 역할을 연결하는 매핑 테이블이다. 현재 확인된 컬럼 구조를 그대로 사용한다.

```sql
CREATE TABLE SMS.TB_EMP_ROLE (
    EMP_ID    VARCHAR2(12) NOT NULL,
    DEP_ID    VARCHAR2(12) NOT NULL,
    ROLE_CD   VARCHAR2(30) NOT NULL,
    USE_YN    CHAR(1)      DEFAULT 'Y' NOT NULL,
    REG_ID    VARCHAR2(12) NOT NULL,
    REG_DTTM  TIMESTAMP(6) DEFAULT SYSTIMESTAMP NOT NULL,
    UPD_ID    VARCHAR2(12),
    UPD_DTTM  TIMESTAMP(6),
    CONSTRAINT PK_TB_EMP_ROLE PRIMARY KEY (EMP_ID, DEP_ID, ROLE_CD),
    CONSTRAINT FK_TB_EMP_ROLE_EMP FOREIGN KEY (EMP_ID, DEP_ID)
        REFERENCES SMS.EMP (EMP_ID, DEP_ID),
    CONSTRAINT FK_TB_EMP_ROLE_ROLE FOREIGN KEY (ROLE_CD)
        REFERENCES SMS.TB_ROLE (ROLE_CD),
    CONSTRAINT CK_TB_EMP_ROLE_USE_YN CHECK (USE_YN IN ('Y', 'N'))
);

CREATE INDEX SMS.IX_TB_EMP_ROLE_01 ON SMS.TB_EMP_ROLE (ROLE_CD);
CREATE INDEX SMS.IX_TB_EMP_ROLE_02 ON SMS.TB_EMP_ROLE (DEP_ID, EMP_ID);
```

컬럼 의미:

| 컬럼 | 의미 |
|---|---|
| `EMP_ID` | 직원 ID. `EMP.EMP_ID` |
| `DEP_ID` | 부서 ID. `EMP.DEP_ID` |
| `ROLE_CD` | 부여할 역할 코드. `TB_ROLE.ROLE_CD` |
| `USE_YN` | 해당 사용자-역할 매핑 사용 여부 |
| `REG_ID`, `REG_DTTM` | 최초 등록자/등록일시 |
| `UPD_ID`, `UPD_DTTM` | 최종 수정자/수정일시 |

중요한 점은 `TB_EMP_ROLE`에 `MENU_ID`, `CAN_READ`, `CAN_CREATE`, `CAN_UPDATE`, `CAN_DELETE` 같은 화면 권한 컬럼을 넣지 않는다는 것이다. 화면별 권한은 `TB_MENU_AUTH`가 담당하고, `TB_EMP_ROLE`은 직원이 어떤 역할을 갖는지만 저장한다.

```text
EMP(사용자) -> TB_EMP_ROLE(사용자-역할) -> TB_ROLE(역할) -> TB_MENU_AUTH(역할별 화면 권한)
```

관리자 역할을 한 사용자에게 부여하는 기본 DML 예시는 다음과 같다.

```sql
INSERT INTO SMS.TB_EMP_ROLE (
    EMP_ID, DEP_ID, ROLE_CD, USE_YN, REG_ID
) VALUES (
    'E001', 'D001', 'ROLE_ADMIN', 'Y', 'SYSTEM'
);
```

이미 매핑이 있으면 활성화하고, 없으면 새로 넣는 방식은 `MERGE`를 사용한다.

```sql
MERGE INTO SMS.TB_EMP_ROLE T
USING (
    SELECT
        'E001' EMP_ID,
        'D001' DEP_ID,
        'ROLE_ADMIN' ROLE_CD
    FROM DUAL
) S
ON (
    T.EMP_ID = S.EMP_ID
    AND T.DEP_ID = S.DEP_ID
    AND T.ROLE_CD = S.ROLE_CD
)
WHEN MATCHED THEN UPDATE SET
    T.USE_YN = 'Y',
    T.UPD_ID = 'SYSTEM',
    T.UPD_DTTM = SYSTIMESTAMP
WHEN NOT MATCHED THEN INSERT (
    EMP_ID, DEP_ID, ROLE_CD, USE_YN, REG_ID
) VALUES (
    S.EMP_ID, S.DEP_ID, S.ROLE_CD, 'Y', 'SYSTEM'
);
```

사용자관리 화면에서 역할을 저장할 때는 선택된 `(EMP_ID, DEP_ID)` 기준으로 기존 역할 매핑을 정리한 뒤, 체크된 역할만 다시 넣는 방식이 단순하다.

```sql
DELETE FROM SMS.TB_EMP_ROLE
WHERE EMP_ID = 'E001'
  AND DEP_ID = 'D001';

INSERT INTO SMS.TB_EMP_ROLE (EMP_ID, DEP_ID, ROLE_CD, USE_YN, REG_ID)
VALUES ('E001', 'D001', 'ROLE_USER', 'Y', 'SYSTEM');

INSERT INTO SMS.TB_EMP_ROLE (EMP_ID, DEP_ID, ROLE_CD, USE_YN, REG_ID)
VALUES ('E001', 'D001', 'ROLE_MANAGER', 'Y', 'SYSTEM');
```

이 delete 후 insert 방식은 사용자에게 남겨둘 역할만 명확하게 저장할 수 있어서 화면 체크박스 UI와 잘 맞는다. 단, 저장 트랜잭션 안에서 처리해야 중간 실패 시 역할 매핑이 비는 상황을 막을 수 있다.

---

## 8. 미확정 항목

- 3장의 역할별 권한 매트릭스는 화면명과 역할 설명 기반 추론이며, 실제 업무 승인 권한·개인정보 접근 범위는 업무 담당자 확인이 필요하다.
- `SMS_SSN_SEARCH`(주민번호 조회)의 `CAN_MASK_VIEW` 부여 대상은 보안 정책상 별도 승인이 필요할 수 있다.
- 한 직원이 여러 역할을 가질 때 충돌하는 플래그는 **OR로 합산된다.** `MenuAuthMapper.xml`의 `selectMenuPermissions`가 역할별 권한을 `MAX(CAN_*)`로 집계하므로, 여러 역할 중 하나라도 `'Y'`면 그 권한은 허용된다. 즉 한 직원에게 `ROLE_VIEWER`와 `ROLE_MANAGER`를 동시에 주면 `ROLE_MANAGER` 쪽 권한이 그대로 살아남고 `ROLE_VIEWER`로 권한을 깎을 수 없다. 권한을 좁히고 싶으면 약한 역할 하나만 배정해야 한다.
