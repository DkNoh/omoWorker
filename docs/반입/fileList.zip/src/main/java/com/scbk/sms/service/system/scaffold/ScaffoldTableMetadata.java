package com.scbk.sms.service.system.scaffold;

import java.util.List;
import java.util.Map;

public record ScaffoldTableMetadata(
    List<String> pkColumns,
    Map<String, Boolean> nullableByColumn,
    Map<String, String> commentsByColumn) {

  public ScaffoldTableMetadata(
      List<String> pkColumns, Map<String, Boolean> nullableByColumn) {
    this(pkColumns, nullableByColumn, Map.of());
  }

  public boolean isNullable(String columnName) {
    if (columnName == null) {
      return true;
    }
    return nullableByColumn.getOrDefault(columnName.trim().toUpperCase(), true);
  }

  public String comment(String columnName) {
    if (columnName == null) {
      return "";
    }
    return commentsByColumn.getOrDefault(columnName.trim().toUpperCase(), "");
  }
}
