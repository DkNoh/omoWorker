package com.scbk.sms.service.system;

import com.scbk.sms.config.ScaffoldProperties;
import com.scbk.sms.dto.system.ScaffoldApplyFileResultDTO;
import com.scbk.sms.dto.system.ScaffoldCaseRecord;
import com.scbk.sms.dto.system.ScaffoldRequestDTO;
import com.scbk.sms.service.system.scaffold.ColumnTypeInferrer;
import com.scbk.sms.service.system.scaffold.QueryColumnExtractor;
import com.scbk.sms.service.system.scaffold.QueryColumnExtractor.SearchParameterSource;
import com.scbk.sms.service.system.scaffold.QueryColumnExtractor.SearchRangePosition;
import com.scbk.sms.service.system.scaffold.ScaffoldArtifactRenderer;
import com.scbk.sms.service.system.scaffold.ScaffoldCaseStore;
import com.scbk.sms.service.system.scaffold.ScaffoldDialect;
import com.scbk.sms.service.system.scaffold.ScaffoldFileApplier;
import com.scbk.sms.service.system.scaffold.ScaffoldMetadataReader;
import com.scbk.sms.service.system.scaffold.ScaffoldModel;
import com.scbk.sms.service.system.scaffold.ScaffoldTableMetadata;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

/** QuerySpec(rawQuery + $변수)에서 화면 1세트의 코드를 생성하고, local 전용 apply 요청에서는 정해진 프로젝트 경로로 저장한다. */
@Service
@Profile("local")
public class ScaffoldService {

  private final ColumnTypeInferrer columnTypeInferrer;
  private final ScaffoldFileApplier scaffoldFileApplier;
  private final ScaffoldMetadataReader metadataReader;
  private final ScaffoldProperties scaffoldProperties;
  private final ScaffoldCaseStore caseStore;

  public ScaffoldService(
      ColumnTypeInferrer columnTypeInferrer,
      ScaffoldFileApplier scaffoldFileApplier,
      ScaffoldMetadataReader metadataReader,
      ScaffoldProperties scaffoldProperties,
      ScaffoldCaseStore caseStore) {
    this.columnTypeInferrer = columnTypeInferrer;
    this.scaffoldFileApplier = scaffoldFileApplier;
    this.metadataReader = metadataReader;
    this.scaffoldProperties = scaffoldProperties;
    this.caseStore = caseStore;
  }

  public Map<String, String> generate(ScaffoldRequestDTO request) {
    return generateFiles(request);
  }

  public Map<String, Object> analyze(String rawQuery, String targetTable) {
    String resolvedTargetTable =
        hasText(targetTable) ? targetTable : QueryColumnExtractor.extractPrimaryTable(rawQuery);
    ScaffoldTableMetadata metadata = metadataReader.read(resolvedTargetTable);
    List<String> columns = QueryColumnExtractor.extractColumns(rawQuery);
    List<String> searchVars = QueryColumnExtractor.extractSearchVars(rawQuery);
    Map<String, Object> result = new LinkedHashMap<>();
    result.put("columns", columns);
    result.put("searchVars", searchVars);
    result.put("targetTable", resolvedTargetTable);
    result.put("pkColumns", metadata.pkColumns());
    result.put("nullableColumns", metadata.nullableByColumn());
    result.put("columnComments", resolveColumnComments(rawQuery, columns, metadata));
    result.put("searchParamLabels", resolveSearchParamLabels(rawQuery, searchVars, metadata));
    result.put("dbPlatform", scaffoldProperties.getDbPlatform());
    return result;
  }

  private Map<String, String> resolveSearchParamLabels(
      String rawQuery, List<String> searchVars, ScaffoldTableMetadata metadata) {
    Map<String, SearchParameterSource> sources =
        QueryColumnExtractor.extractSearchParameterSources(rawQuery);
    Map<String, String> directSources = QueryColumnExtractor.extractDirectColumnSources(rawQuery);
    Map<String, String> result = new LinkedHashMap<>();
    for (String searchVar : searchVars) {
      SearchParameterSource source = sources.get(searchVar);
      String label = "";
      if (source != null && source.rangePosition() == SearchRangePosition.START) {
        label = "시작일자";
      } else if (source != null && source.rangePosition() == SearchRangePosition.END) {
        label = "종료일자";
      } else if (source != null) {
        label = metadata.comment(source.columnName());
        if (!hasText(label)) {
          label = findOutputAlias(directSources, source.columnName());
        }
      }
      result.put(searchVar, hasText(label) ? label.trim() : searchVar);
    }
    return result;
  }

  private String findOutputAlias(Map<String, String> directSources, String sourceColumn) {
    return directSources.entrySet().stream()
        .filter(entry -> entry.getValue().equals(sourceColumn))
        .map(Map.Entry::getKey)
        .findFirst()
        .orElse("");
  }

  private Map<String, String> resolveColumnComments(
      String rawQuery, List<String> columns, ScaffoldTableMetadata metadata) {
    Map<String, String> directSources = QueryColumnExtractor.extractDirectColumnSources(rawQuery);
    Map<String, String> result = new LinkedHashMap<>();
    for (String column : columns) {
      String outputColumn = normalizeColumn(column);
      String sourceColumn = directSources.getOrDefault(outputColumn, outputColumn);
      String comment = metadata.comment(sourceColumn);
      if (!hasText(comment) && !sourceColumn.equals(outputColumn)) {
        comment = metadata.comment(outputColumn);
      }
      if (hasText(comment)) {
        result.put(outputColumn, comment.trim());
      }
    }
    return result;
  }

  public List<ScaffoldApplyFileResultDTO> preview(ScaffoldRequestDTO request) {
    Map<String, String> generatedFiles = generateFiles(request);
    return scaffoldFileApplier.preview(request, generatedFiles);
  }

  public List<ScaffoldApplyFileResultDTO> apply(ScaffoldRequestDTO request) {
    List<String> columns = QueryColumnExtractor.extractColumns(request.getRawQuery());
    List<String> searchVars = QueryColumnExtractor.extractSearchVars(request.getRawQuery());
    Map<String, String> typeMap = columnTypeInferrer.inferTypes(request.getRawQuery(), columns);
    ScaffoldCaseRecord record = new ScaffoldCaseRecord();
    record.setRequest(request);
    record.setColumns(columns);
    record.setSearchVars(searchVars);
    record.setTypeMap(typeMap);
    record.setDialect(scaffoldProperties.dialect().name());
    caseStore.save(record);

    Map<String, String> generatedFiles = generateFiles(request);
    return scaffoldFileApplier.apply(request, generatedFiles);
  }

  private Map<String, String> generateFiles(ScaffoldRequestDTO request) {
    List<String> columns = QueryColumnExtractor.extractColumns(request.getRawQuery());
    if (columns.isEmpty()) {
      throw new IllegalStateException("rawQuery에서 SELECT 컬럼을 추출하지 못했습니다. 쿼리를 확인하세요.");
    }
    List<String> searchVars = QueryColumnExtractor.extractSearchVars(request.getRawQuery());
    Map<String, String> typeMap = columnTypeInferrer.inferTypes(request.getRawQuery(), columns);
    ScaffoldDialect dialect = scaffoldProperties.dialect();
    enrichAndValidateCrudRequest(request, columns);

    ScaffoldModel model = new ScaffoldModel(request, columns, searchVars, typeMap, dialect);
    return ScaffoldArtifactRenderer.renderAll(model);
  }

  private void enrichAndValidateCrudRequest(ScaffoldRequestDTO request, List<String> columns) {
    ScaffoldModel baseModel =
        new ScaffoldModel(request, columns, List.of(), Map.of(), scaffoldProperties.dialect());
    if (!baseModel.includeCreateUpdate()) {
      return;
    }

    String targetTable = baseModel.targetTable();
    if (!hasText(targetTable)) {
      throw new IllegalStateException("CRUD mode requires targetTable.");
    }

    ScaffoldTableMetadata metadata = metadataReader.read(targetTable);
    if (metadata.pkColumns().isEmpty()) {
      throw new IllegalStateException(
          "CRUD mode requires a real primary key. Table has no PK: " + targetTable);
    }

    List<String> pkColumns =
        request.getPkColumns().isEmpty()
            ? metadata.pkColumns()
            : normalizeColumns(request.getPkColumns());
    request.setPkColumns(pkColumns);
    request.setPkColumn(pkColumns.get(0));

    List<String> queryColumns = normalizeColumns(columns);
    for (String pkColumn : pkColumns) {
      if (!queryColumns.contains(pkColumn)) {
        throw new IllegalStateException("CRUD query must include PK column: " + pkColumn);
      }
    }

    String lockColumn = normalizeColumn(request.getLockColumn());
    if (hasText(lockColumn)) {
      if (!queryColumns.contains(lockColumn)) {
        throw new IllegalStateException("CRUD query must include lock column: " + lockColumn);
      }
      if (!metadata.nullableByColumn().containsKey(lockColumn)) {
        throw new IllegalStateException(
            "Lock column does not exist in target table: " + lockColumn);
      }
      if (pkColumns.contains(lockColumn)) {
        throw new IllegalStateException(
            "Optimistic lock column must not be a PK column: " + lockColumn);
      }
    }
  }

  private static List<String> normalizeColumns(List<String> columns) {
    return columns.stream()
        .map(ScaffoldService::normalizeColumn)
        .filter(ScaffoldService::hasText)
        .distinct()
        .toList();
  }

  private static String normalizeColumn(String column) {
    return column == null ? "" : column.trim().toUpperCase();
  }

  private static boolean hasText(String value) {
    return value != null && !value.trim().isEmpty();
  }
}
